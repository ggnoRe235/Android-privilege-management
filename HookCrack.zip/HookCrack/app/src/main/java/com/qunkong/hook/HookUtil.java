package com.qunkong.hook;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AndroidAppHelper;
import android.app.Application;
import android.app.ListActivity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;
import static de.robv.android.xposed.XposedHelpers.findAndHookMethod;
import android.content.Context;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RemoteViews;
import android.widget.Toast;


public class HookUtil implements IXposedHookLoadPackage
{

    private static void findHookAppName() {
        //XposedBridge.log("检测目录下hook框架");
        try{
            FileWriter fw = new FileWriter("/storage/emulated/legacy/static.txt",true);
            //XposedBridge.log(Environment.getExternalStorageDirectory().toString());
            fw.write("检测目录下的hook框架\n");   //找Xposed等等框架
            Context context = AndroidAppHelper.currentApplication();
            PackageManager packageManager = context.getPackageManager();
            List<ApplicationInfo> applicationInfoList = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);

            for(ApplicationInfo applicationInfo : applicationInfoList)
            {
                if(applicationInfo.packageName.equals("de.robv.android.xposed.installer"));
                {
                    String dir = applicationInfo.sourceDir;
                    //XposedBridge.log("Xposed found on the system " + dir);
                    fw.write("Xposed found on the system  " + dir + "\n");
                }
                if(applicationInfo.packageName.equals("com.saurik.substrate"))
                {
                    int labelRes = applicationInfo.labelRes;
                    //XposedBridge.log("Substrate found on the system " + context.getResources().getString(labelRes));
                    fw.write("Substrate found on the system " + context.getResources().getString(labelRes));
                }
            }
            fw.close();
        }
        catch(Exception e){
            //XposedBridge.log(e);
        }
    }

    private static void getInstalled(){
        Application application = AndroidAppHelper.currentApplication();
        PackageManager packageManager = application.getPackageManager();
        List<ApplicationInfo> infos = packageManager.getInstalledApplications(PackageManager.GET_ACTIVITIES);
        try{
            FileWriter fw = new FileWriter("/storage/emulated/legacy/static2.txt",true);
            fw.write("num of app  " + infos.size() + "\n");
            for(ApplicationInfo info:infos)
            {
                fw.write("appName --->" + packageManager.getApplicationLabel(info) + "\n");
                try{
                    PackageInfo packInfo = packageManager.getPackageInfo(info.packageName,PackageManager.GET_PERMISSIONS);
                    String permissions[] = packInfo.requestedPermissions;
                    int length = permissions.length;
                    float fina_score = 180 - 2 * length;
                    fina_score = (fina_score / 180) * 100;
                    int final_score = (int)(fina_score+0.5f);
                    int count=0;
                    for(int i=0; i<length; i++)
                    {
                        String n = (String) packageManager.getApplicationLabel(info);
                        if(permissions[i].contains("ACCESS_SUPERUSER") || n.contains("Hook"))
                        {
                            final_score =0;
                            fw.write("appName --->" + packageManager.getApplicationLabel(info) + permissions[i] +" * \n");
                            count = count +20;
                        }
                        else if(permissions[i].contains("CAMERA") || permissions[i].contains("WRITE_SETTINGS") || permissions[i].contains("BIND_CALL_SERVICE") || permissions[i].contains("CHANGE_WIFI_STATE")|| permissions[i].contains("MANAGE_ACCOUNTS"))
                        {
                            fw.write("appName --->" + packageManager.getApplicationLabel(info) + permissions[i] +" * \n");
                            count++;
                        }
                        else fw.write("appName --->" + packageManager.getApplicationLabel(info) + permissions[i] +"\n");
                    }

                    if((packInfo.applicationInfo.flags & info.FLAG_SYSTEM) == 0)
                    {
                        fw.write("appName --->" + packageManager.getApplicationLabel(info) + "final score  --->  " + final_score + "\n");
                        if(count>=3 && count<20) fw.write("appName --->" + packageManager.getApplicationLabel(info) + "较危险" + "\n");
                        if(count>=20) fw.write("appName --->" + packageManager.getApplicationLabel(info) + "不可信" + "\n");
                        if(count<3) fw.write("appName --->" + packageManager.getApplicationLabel(info) + "较安全"+"\n");
                    }
                    else{
                        fw.write("appName --->" + packageManager.getApplicationLabel(info) + "final score  --->  " + final_score + "\n");
                        if(count>=3 && count<20) fw.write("appName --->" + packageManager.getApplicationLabel(info) + "较危险" + "(系统应用)\n");
                        if(count>=20) fw.write("appName --->" + packageManager.getApplicationLabel(info) + "不可信" + "(系统应用)\n");
                        if(count<3) fw.write("appName --->" + packageManager.getApplicationLabel(info) + "较安全"+"(系统应用)\n");

                        //fw.write("appName --->" + packageManager.getApplicationLabel(info) + "(这是一个系统应用，较安全)" + "\n");
                    }

                    fw.write("==========================================================================" + "\n");
                }
                catch(Exception e){}
            }
            fw.close();
        }
        catch(Exception e){}
    }

    public static void hook_check(){
        File file = new File("/storage/emulated/legacy/static.txt");
        try{
            if(!file.exists())
            {
                file.createNewFile();
            }

        }
        catch(Exception e){}
        if(file.length()==0){
            findHookAppName();
        }
        File file2 = new File("/storage/emulated/legacy/static2.txt");
        try{
            if(!file2.exists())
            {
                file2.createNewFile();
            }
        }
        catch(Exception e){}
        if(file2.length()==0)
        {
            getInstalled();
        }
        //findHookStack();
        //这个功能是找stack中的hook，但是淡印出来有点乱，我就没放出来
    }

    private static void WarningMessage(String text){
        //Bitmap btm = BitmapFactory.decodeResource(getResources(),R.drawable.ic_launcher_foreground);
        long[] vibrate = {0,1000,1000,1000};
        Uri soundUri = Uri.fromFile(new File("/system/media/audio/alarms/Alarm_Beep_01.ogg"));
        Context context = AndroidAppHelper.currentApplication();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder builder = new Notification.Builder(context)
                .setAutoCancel(true)
                .setContentTitle("warning")
                .setContentText(text)
                .setVibrate(vibrate)
                .setSound(soundUri)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setWhen(System.currentTimeMillis())
                .setOngoing(true);
        Notification notification = builder.build();
        manager.notify(1,notification);
    }

    private static boolean getflag() {
        boolean r = false;
        try{
            FileInputStream fr = new FileInputStream("/storage/emulated/legacy/flag.txt");
            InputStreamReader streamReader = new InputStreamReader(fr);
            BufferedReader reader = new BufferedReader(streamReader);
            String flag = reader.readLine();
            reader.close();
            streamReader.close();
            fr.close();
            if(flag.contains("true")) r=true;
            else r=false;
        }
        catch(Exception e){return false;}
        return r;
    }

    private static String getblacklist() {
        String information = "";
        try{
            FileInputStream fr = new FileInputStream("/storage/emulated/legacy/blacklist.txt");
            InputStreamReader streamReader = new InputStreamReader(fr);
            BufferedReader reader = new BufferedReader(streamReader);
            information = reader.readLine();
            reader.close();
            streamReader.close();
            fr.close();
        }
        catch(Exception e){return "";}
        return information;
    }

    private static void insertcontent(String content,String name){
        StringBuilder stringBuilder = new StringBuilder();
        String information = "";
        try{
            int final_score = 0;

            //"appName --->" + name + "final score  --->  " + final_score + "\n"

            FileInputStream fr = new FileInputStream("/storage/emulated/legacy/static2.txt");
            InputStreamReader streamReader = new InputStreamReader(fr);
            BufferedReader reader = new BufferedReader(streamReader);
            boolean flag = false;
            while((information = reader.readLine())!=null)
            {
                if(information.contains(name) && information.contains("final"))
                {
                    if(flag == false)
                    {
                        stringBuilder.append(content +"\n");
                        flag = true;
                    }
                    int number =-1;
                    for(int i=0;i<information.length();i++)
                    {
                        String c = information.substring(i,i+2);
                        String cc = information.substring(i,i+1);
                        String ccc = information.substring(i,i);
                        try{
                            number = Integer.parseInt(c);
                            if(number >=1 )number = number - 1;
                        }
                        catch(Exception e){number = -1;}
                        if(number == -1 )
                        {
                            try{
                                number = Integer.parseInt(cc);
                                if(number >=1 ) number = number -1;
                            }
                            catch(Exception e){number = -1;}
                            if(number == -1)
                            {
                                try{
                                    number = Integer.parseInt(ccc);
                                    if(number >=1 )number = number -1;
                                }
                                catch(Exception e){number = -1;}
                            }
                        }
                        if(number != -1) break;
                    }
                    final_score = number;
                    information = "appName --->" + name + "final score  --->  " + final_score + "\n";
                    stringBuilder.append(information + "\n");
                }
                else{
                    stringBuilder.append(information + "\n");
                }
            }
            reader.close();
            streamReader.close();
            fr.close();
            String f = stringBuilder.toString();
            FileWriter fw = new FileWriter("/storage/emulated/legacy/static2.txt");
            fw.write(f);
            fw.close();
        }
        catch(Exception e){}
    }

    @Override
    public void handleLoadPackage(final LoadPackageParam lpparam) throws Throwable
    {
        hook_check();
        //检测发送短信
        findAndHookMethod("android.telephony.SmsManager",lpparam.classLoader,"sendTextMessage",String.class, String.class,String.class,PendingIntent.class,PendingIntent.class,new XC_MethodHook(){
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                    String name = param.toString();
                    Application application = AndroidAppHelper.currentApplication();
                    if(application != null)
                    {
                        String packageName = application.getPackageName();
                        try{
                            ApplicationInfo packageInfo = application.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_META_DATA);
                            String appName = application.getPackageManager().getApplicationLabel(packageInfo).toString();
                            //XposedBridge.log(appName);
                            XposedBridge.log("send message" + appName);
                                FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt",true);
                                fw.write("send message" + appName + "\n");
                                fw.close();
                                insertcontent(appName + " is sending message",appName);
                                WarningMessage(appName + " is sending message");
                        }
                        catch(Exception e)
                        {
                            //XposedBridge.log(e);
                        }
                    }
                }
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
                });
        //检测拍照
        findAndHookMethod("android.hardware.Camera",lpparam.classLoader,"takePicture", Camera.ShutterCallback.class,Camera.PictureCallback.class,Camera.PictureCallback.class, Camera.PictureCallback.class,new XC_MethodHook(){
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                     if(getflag()) {
                        param.args[3] = null;
                        param.args[2] = null;
                        param.args[1] = null;
                        param.args[0] = null;
                        //返回空相册
                    }
                        String name = param.toString();
                        Application application = AndroidAppHelper.currentApplication();
                        if(application != null)
                        {
                            String packageName = application.getPackageName();
                            try{
                                ApplicationInfo packageInfo = application.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_META_DATA);
                                String appName = application.getPackageManager().getApplicationLabel(packageInfo).toString();
                                String ch = getblacklist();
                                XposedBridge.log("take picture detection" + appName);
                                FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt",true);
                                fw.write("take picture" + appName + "\n");
                                fw.close();
                                if(ch.contains(appName))
                                {
                                    param.args[3] = null;
                                    param.args[2] = null;
                                    param.args[1] = null;
                                    param.args[0] = null;
                                }
                                insertcontent(appName + " is taking picture",appName);
                                WarningMessage(appName + " is taking picture");
                            }
                            catch(Exception e)
                            {
                                //XposedBridge.log(e);
                            }
                        }
                    }
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
                });
        //检测读取号码信息
        findAndHookMethod("android.telephony.TelephonyManager",lpparam.classLoader,"getLine1Number",new XC_MethodHook(){
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                String name = param.toString();
                if(getflag())
                {
                    String number = "1234567890123";
                    param.setResult(number);
                }

                    //返回一个伪造的号码
                    Application application = AndroidAppHelper.currentApplication();
                    if(application != null)
                    {
                        String packageName = application.getPackageName();
                        try{
                            ApplicationInfo packageInfo = application.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_META_DATA);
                            String appName = application.getPackageManager().getApplicationLabel(packageInfo).toString();
                            XposedBridge.log("read telephone number detection" + appName);
                            FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt",true);
                            fw.write("read telephone number detection" + appName + "\n");
                            fw.close();
                            insertcontent(appName + " is reading telephone number",appName);
                            WarningMessage(appName + " is reading telephone number");
                        }
                        catch(Exception e)
                        {
                            //XposedBridge.log(e);
                        }
                    }
            }
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
        });
        //检测在通知栏发通知
        findAndHookMethod("android.app.NotificationManager",lpparam.classLoader,"notify",int.class, Notification.class,new XC_MethodHook(){
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                String name = param.toString();
                Application application = AndroidAppHelper.currentApplication();
                if(application != null)
                {
                    String packageName = application.getPackageName();
                    try{
                        ApplicationInfo packageInfo = application.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_META_DATA);
                        String appName = application.getPackageManager().getApplicationLabel(packageInfo).toString();
                        XposedBridge.log("send Notification detection" + appName);
                        FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt",true);
                        fw.write("send Notification detection" + appName + "\n");
                        fw.close();
                        insertcontent(appName + " is sending Notification",appName);
                        //if(!appName.equals("Hook") )WarningMessage();

                    }
                    catch(Exception e)
                    {
                        //XposedBridge.log(e);
                    }
                }
            }
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
        });
        //检测开启录音服务
        findAndHookMethod("android.media.AudioRecord",lpparam.classLoader,"startRecording",new XC_MethodHook(){
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                String name = param.toString();
                Application application = AndroidAppHelper.currentApplication();
                if(application != null)
                {
                    String packageName = application.getPackageName();
                    try{
                        ApplicationInfo packageInfo = application.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_META_DATA);
                        String appName = application.getPackageManager().getApplicationLabel(packageInfo).toString();
                        XposedBridge.log("start recording detection" + appName);
                        FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt",true);
                        fw.write("start recording detection" + appName + "\n");
                        fw.close();
                        insertcontent(appName + " is recording",appName);
                        WarningMessage(appName + " is recording");
                    }
                    catch(Exception e)
                    {
                        //XposedBridge.log(e);
                    }
                }
            }
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
        });
        //检测读取账户
        findAndHookMethod("android.accounts.AccountManager",lpparam.classLoader,"getAccounts",new XC_MethodHook(){
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                //从文件中读一个flag出来决定要不要返回空的list
                if(getflag())
                {
                    List<Account> list = null;
                    param.setResult(list);
                }
                    String name = param.toString();
                    Application application = AndroidAppHelper.currentApplication();
                    if(application != null)
                    {
                        String packageName = application.getPackageName();
                        try{
                            ApplicationInfo packageInfo = application.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_META_DATA);
                            String appName = application.getPackageManager().getApplicationLabel(packageInfo).toString();
                            XposedBridge.log("get account detection" + appName);
                            FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt",true);
                            fw.write("get account detection" + appName + "\n");
                            fw.close();
                            String ch = getblacklist();
                            if(ch.contains(appName))
                            {
                                List<Account> list = null;
                                param.setResult(list);
                            }
                            insertcontent(appName + " is getting account",appName);
                            WarningMessage(appName +" is getting account");
                        }
                        catch(Exception e)
                        {
                            //XposedBridge.log(e);
                        }
                    }

            }
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
        });
        //检测录像
        findAndHookMethod("android.media.MediaRecorder",lpparam.classLoader,"start",new XC_MethodHook(){
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                String name = param.toString();
                Application application = AndroidAppHelper.currentApplication();
                if(application != null)
                {
                    String packageName = application.getPackageName();
                    try{
                        ApplicationInfo packageInfo = application.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_META_DATA);
                        String appName = application.getPackageManager().getApplicationLabel(packageInfo).toString();
                        XposedBridge.log("start recording detection" + appName);
                        FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt",true);
                        fw.write("start recording detection" + appName + "\n");
                        fw.close();
                        insertcontent(appName + " is recording",appName);
                        WarningMessage(appName + " is recording");
                    }
                    catch(Exception e)
                    {
                        //XposedBridge.log(e);
                    }
                }
            }
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
        });
        //检测是否在读取地址
        findAndHookMethod("android.location.Address",lpparam.classLoader,"getAddressLine",int.class,new XC_MethodHook(){
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                String name = param.toString();
                Application application = AndroidAppHelper.currentApplication();
                if(application != null)
                {
                    String packageName = application.getPackageName();
                    try{
                        ApplicationInfo packageInfo = application.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_META_DATA);
                        String appName = application.getPackageManager().getApplicationLabel(packageInfo).toString();
                        XposedBridge.log("locating detection" + appName);
                        FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt",true);
                        fw.write("locating detection" + appName + "\n");
                        fw.close();
                        insertcontent(appName + " is locating",appName);
                        WarningMessage(appName + " is locating");
                    }
                    catch(Exception e)
                    {
                        //XposedBridge.log(e);
                    }
                }
            }
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
        });
        //检查打开wifi行为
        findAndHookMethod("android.net.wifi.WifiManager",lpparam.classLoader,"setWifiEnabled",boolean.class,new XC_MethodHook(){
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                if(getflag()) param.args[0] = false;

                    String name = param.toString();
                    Application application = AndroidAppHelper.currentApplication();
                    if(application != null)
                    {
                        String packageName = application.getPackageName();
                        try{
                            ApplicationInfo packageInfo = application.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_META_DATA);
                            String appName = application.getPackageManager().getApplicationLabel(packageInfo).toString();
                            String ch = getblacklist();
                            XposedBridge.log("connecting to wifi" + appName);
                            FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt",true);
                            fw.write("connecting to wifi" + appName + "\n");
                            fw.close();
                            if(ch.contains(appName))
                            {
                                param.args[0] = false;
                            }
                            insertcontent(appName + " want to open wifi",appName);
                            WarningMessage(appName + " want to open wifi");
                        }
                        catch(Exception e)
                        {
                            //XposedBridge.log(e);
                        }
                    }


            }
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
        });
        //与前端同步
        findAndHookMethod("com.example.logindemo.MainActivity",lpparam.classLoader,"rewrite",new XC_MethodHook(){
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable{
                XposedBridge.log("test");
                try{
                    FileWriter fw = new FileWriter("/storage/emulated/legacy/dynamic.txt");
                    fw.write("");
                    fw.close();

                    FileWriter fw1 = new FileWriter("/storage/emulated/legacy/static.txt");
                    fw1.write("");
                    fw1.close();

                    FileWriter fw2 = new FileWriter("/storage/emulated/legacy/static2.txt");
                    fw2.write("");
                    fw2.close();

                    FileWriter fw3 = new FileWriter("/storage/emulated/legacy/blacklist.txt");
                    fw3.write("false");
                    fw3.close();

                    XposedBridge.log("finish rewrite");
                }
                catch(Exception e) { }

                findHookAppName();
                getInstalled();
            }
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
        });

    }
}